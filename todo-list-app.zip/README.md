# To-Do List App
Simple To-Do List app using Node.js, Express, and Vanilla JS.
