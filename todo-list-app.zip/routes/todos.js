const express = require("express");
const router = express.Router();

let todos = [];

router.get("/", (req, res) => {
  res.json(todos);
});

router.post("/", (req, res) => {
  const { text } = req.body;
  if (!text) return res.status(400).json({ error: "Task text is required" });
  const newTodo = { id: Date.now(), text, completed: false };
  todos.push(newTodo);
  res.json(newTodo);
});

router.put("/:id", (req, res) => {
  const { id } = req.params;
  todos = todos.map(todo =>
    todo.id == id ? { ...todo, completed: !todo.completed } : todo
  );
  res.json({ success: true });
});

router.delete("/:id", (req, res) => {
  const { id } = req.params;
  todos = todos.filter(todo => todo.id != id);
  res.json({ success: true });
});

module.exports = router;